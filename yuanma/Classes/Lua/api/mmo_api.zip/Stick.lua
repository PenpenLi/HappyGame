
--------------------------------
-- @module Stick
-- @extend Node
-- @parent_module mmo

--------------------------------
-- 
-- @function [parent=#Stick] onTouchMoved 
-- @param self
-- @param #vec2_table pos
        
--------------------------------
-- 
-- @function [parent=#Stick] handleTouchChange 
-- @param self
-- @param #vec2_table pos
        
--------------------------------
-- 
-- @function [parent=#Stick] hide 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Stick] getAngle 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#Stick] getIsWorking 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Stick] needUpdate 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Stick] onTouchBegan 
-- @param self
-- @param #vec2_table pos
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Stick] init 
-- @param self
-- @param #string strBottomFrameName
-- @param #string strStickFrameName
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Stick] getDirection 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#Stick] setIsWorking 
-- @param self
-- @param #bool isWorking
        
--------------------------------
-- 
-- @function [parent=#Stick] onTouchEnded 
-- @param self
-- @param #vec2_table pos
        
--------------------------------
-- 
-- @function [parent=#Stick] createWithFrameName 
-- @param self
-- @param #string strBottomFrameName
-- @param #string strStickFrameName
-- @return Stick#Stick ret (return value: Stick)
        
--------------------------------
-- 
-- @function [parent=#Stick] Stick 
-- @param self
        
return nil
