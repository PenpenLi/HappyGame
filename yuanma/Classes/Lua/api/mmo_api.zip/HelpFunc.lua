
--------------------------------
-- @module HelpFunc
-- @parent_module mmo

--------------------------------
-- 
-- @function [parent=#HelpFunc] gTimeToFrames 
-- @param self
-- @param #double time
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gNumToStr 
-- @param self
-- @param #int nNum
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gDirectionAnalyse 
-- @param self
-- @param #float startX
-- @param #float startY
-- @param #float endX
-- @param #float endY
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] getSystemMSTime 
-- @param self
-- @return long long#long long ret (return value: long long)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gCreateFileWithContent 
-- @param self
-- @param #string fileName
-- @param #string content
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] bitAnd 
-- @param self
-- @param #int p1
-- @param #int p2
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gGetRandNumber 
-- @param self
-- @param #int nRange
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] getSystemSTime 
-- @param self
-- @return long long#long long ret (return value: long long)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gTimeToStr 
-- @param self
-- @param #float fTime
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gFramesToTime 
-- @param self
-- @param #int frames
-- @return double#double ret (return value: double)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] getSystemMTime 
-- @param self
-- @return long long#long long ret (return value: long long)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gAngleAnalyseForRotation 
-- @param self
-- @param #float startX
-- @param #float startY
-- @param #float endX
-- @param #float endY
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gGetMinuteStr 
-- @param self
-- @param #float fTime
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] print 
-- @param self
-- @param #string str
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gShowRectLogInfo 
-- @param self
-- @param #rect_table rect
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] bitOr 
-- @param self
-- @param #int p1
-- @param #int p2
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gGetRandNumberBetween 
-- @param self
-- @param #int nBegin
-- @param #int nEnd
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gAngleAnalyseForQuad 
-- @param self
-- @param #float startX
-- @param #float startY
-- @param #float endX
-- @param #float endY
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#HelpFunc] gGetSecondStr 
-- @param self
-- @param #float fTime
-- @return string#string ret (return value: string)
        
return nil
